import { cn } from "@/lib/utils";

/**
 * MAHAJAN monogram — a modern geometric "M" with an electric blue final stroke.
 */
export function Monogram({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 48 48"
      className={cn("h-10 w-10", className)}
      role="img"
      aria-label="MAHAJAN monogram logo"
    >
      <defs>
        <linearGradient id="mahajan-m-blue" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#6FD2FF" />
          <stop offset="0.5" stopColor="#2E7CFF" />
          <stop offset="1" stopColor="#0B5CFF" />
        </linearGradient>
      </defs>
      <rect
        x="1"
        y="1"
        width="46"
        height="46"
        rx="11"
        className="fill-[#05060B]"
        stroke="rgba(255,255,255,0.14)"
        strokeWidth="1.5"
      />
      <path
        d="M13 33.5 V15 L24 26.5 L35 15 V33.5"
        fill="none"
        stroke="#F4F6FB"
        strokeWidth="4.2"
        strokeLinejoin="miter"
        strokeLinecap="butt"
      />
      <path
        d="M35 15 V33.5"
        fill="none"
        stroke="url(#mahajan-m-blue)"
        strokeWidth="4.2"
        strokeLinecap="butt"
      />
    </svg>
  );
}

/**
 * Full brand lockup: monogram + MAHAJAN wordmark + "WEB DEVELOPMENT STUDIO".
 */
export function Logo({
  className,
  monogramClassName,
  compact = false,
}: {
  className?: string;
  monogramClassName?: string;
  compact?: boolean;
}) {
  return (
    <span className={cn("flex items-center gap-3", className)}>
      <Monogram className={monogramClassName} />
      {!compact && (
        <span className="flex flex-col justify-center">
          <span className="font-display text-lg font-bold leading-none tracking-[0.18em] text-white">
            MAHAJAN
          </span>
          <span className="mt-1.5 text-[8.5px] font-semibold uppercase leading-none tracking-[0.34em] text-electric-400">
            Web Development Studio
          </span>
        </span>
      )}
    </span>
  );
}
