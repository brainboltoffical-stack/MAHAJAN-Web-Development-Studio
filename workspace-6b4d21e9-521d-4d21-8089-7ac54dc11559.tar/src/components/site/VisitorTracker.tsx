"use client";

import { useEffect } from "react";

/**
 * Privacy-first, cookieless analytics beacon for the public site.
 * - Fires once per full page load on the public website only.
 * - Respects the browser Do-Not-Track signal (server double-checks the header).
 * - Sends no personal data: path + referrer domain only; the server derives a
 *   pseudonymous visitor hash and the device category.
 */
export function VisitorTracker() {
  useEffect(() => {
    try {
      const dnt =
        navigator.doNotTrack ||
        (window as unknown as { doNotTrack?: string }).doNotTrack ||
        (navigator as unknown as { msDoNotTrack?: string }).msDoNotTrack;
      if (dnt === "1" || dnt === "yes") return;

      const payload = JSON.stringify({
        p: window.location.pathname + (window.location.hash || ""),
        r: document.referrer || "",
      });
      fetch("/api/track", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: payload,
        keepalive: true,
      }).catch(() => undefined);
    } catch {
      // Analytics must never interfere with browsing.
    }
  }, []);

  return null;
}
