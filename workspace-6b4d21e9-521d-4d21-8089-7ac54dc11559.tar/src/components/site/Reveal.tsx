"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Scroll-reveal wrapper — subtle fade + rise animation when the element
 * enters the viewport. Animates once for a premium, non-distracting feel.
 */
export function Reveal({
  children,
  className,
  delay = 0,
  y = 28,
  as = "div",
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  y?: number;
  as?: "div" | "section" | "span";
}) {
  const MotionTag = as === "section" ? motion.section : as === "span" ? motion.span : motion.div;
  return (
    <MotionTag
      className={cn(className)}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-70px" }}
      transition={{ duration: 0.7, delay, ease: [0.21, 0.47, 0.32, 0.98] }}
    >
      {children}
    </MotionTag>
  );
}
