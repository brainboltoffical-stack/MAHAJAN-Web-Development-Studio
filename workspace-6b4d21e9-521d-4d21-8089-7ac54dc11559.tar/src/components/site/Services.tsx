"use client";

import {
  Building2,
  MousePointerClick,
  Paintbrush,
  MonitorSmartphone,
  ShoppingBag,
  ShoppingCart,
} from "lucide-react";
import { motion } from "framer-motion";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Reveal } from "@/components/site/Reveal";

const SERVICES = [
  {
    icon: Building2,
    title: "Business Website Development",
    description:
      "A polished, trustworthy website that introduces your business, explains your services and turns visitors into enquiries. Ideal for local businesses, consultants and professional service providers.",
    tags: ["Company Profile", "Service Pages", "Contact Forms"],
  },
  {
    icon: ShoppingCart,
    title: "E-commerce Website Development",
    description:
      "A complete online store that makes it easy for customers to browse products, add to cart and check out securely — designed to convert browsers into repeat buyers.",
    tags: ["Product Catalogue", "Secure Checkout", "Payment Integration"],
  },
  {
    icon: ShoppingBag,
    title: "Shopify Store Design",
    description:
      "A custom-designed Shopify store that stands out from generic templates. Your store is designed and structured around your brand so it looks premium and sells effectively.",
    tags: ["Theme Customisation", "Brand Styling", "Store Setup"],
  },
  {
    icon: Paintbrush,
    title: "Website Redesign",
    description:
      "An outdated website quietly costs you customers. We rebuild your existing site with a modern look, faster performance and a structure that works on every device.",
    tags: ["Modern UI", "Speed Optimisation", "Content Restructure"],
  },
  {
    icon: MonitorSmartphone,
    title: "Responsive Website Design",
    description:
      "Every website we build works beautifully on phones, tablets and desktops. Your customers get a flawless experience no matter how they find you — search, social or word of mouth.",
    tags: ["Mobile-First", "Cross-Device Testing", "Touch-Friendly"],
  },
  {
    icon: MousePointerClick,
    title: "Landing Page Development",
    description:
      "A focused, high-converting landing page for your campaign, product or launch — designed around one clear goal: turning visitors into enquiries or sales.",
    tags: ["Conversion Focus", "Fast Delivery", "Campaign Ready"],
  },
];

export function Services() {
  return (
    <section id="services" className="relative py-24 lg:py-32" aria-label="Services">
      <div
        className="absolute left-[-200px] top-40 h-[420px] w-[420px] rounded-full bg-electric-600/[0.07] blur-[130px]"
        aria-hidden
      />
      <div className="relative mx-auto w-full max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Our Services"
          title={
            <>
              Everything Your Business Needs to{" "}
              <span className="text-gradient-electric">Succeed Online</span>
            </>
          }
          subtitle="From your first business website to a full online store, every project is built with modern technology, clean design and your business goals at the centre."
        />

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3 lg:gap-6">
          {SERVICES.map((service, i) => (
            <Reveal key={service.title} delay={(i % 3) * 0.1}>
              <motion.article
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 260, damping: 22 }}
                className="card-border-glow group flex h-full flex-col rounded-2xl border border-white/[0.07] bg-card/70 p-6 transition-colors hover:border-electric-500/25 hover:bg-panel lg:p-7"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-electric-400 to-electric-600 shadow-[0_10px_30px_-8px_rgba(46,124,255,0.6)]">
                  <service.icon className="h-6 w-6 text-white" aria-hidden />
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold text-white">
                  {service.title}
                </h3>
                <p className="mt-3 flex-1 text-[15px] leading-relaxed text-muted-foreground">
                  {service.description}
                </p>
                <ul className="mt-5 flex flex-wrap gap-2" aria-label={`${service.title} includes`}>
                  {service.tags.map((tag) => (
                    <li
                      key={tag}
                      className="rounded-full border border-white/[0.08] bg-white/[0.03] px-3 py-1 text-[11.5px] font-medium tracking-wide text-foreground/70 transition-colors group-hover:border-electric-500/25 group-hover:text-electric-300"
                    >
                      {tag}
                    </li>
                  ))}
                </ul>
              </motion.article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
