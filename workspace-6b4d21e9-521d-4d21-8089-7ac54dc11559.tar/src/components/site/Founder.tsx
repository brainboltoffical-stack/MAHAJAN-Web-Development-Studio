"use client";

import { GraduationCap, Mail, MapPin, Sparkles, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/site/SectionHeading";
import { Reveal } from "@/components/site/Reveal";
import { Monogram } from "@/components/brand/Logo";

const FACTS = [
  { icon: GraduationCap, label: "Education", value: "B.Tech — Artificial Intelligence & Data Science" },
  { icon: Sparkles, label: "Academic Year", value: "Second Year" },
  { icon: MapPin, label: "Location", value: "Pune, Maharashtra, India" },
  { icon: UserRound, label: "Role", value: "Founder & Web Developer" },
];

export function Founder() {
  return (
    <section id="about" className="relative py-24 lg:py-32" aria-label="About the founder">
      <div
        className="absolute left-1/2 top-1/2 h-[480px] w-[720px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-electric-600/[0.06] blur-[140px]"
        aria-hidden
      />
      <div className="relative mx-auto w-full max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Meet the Founder"
          title={
            <>
              The Person Behind <span className="text-gradient-electric">MAHAJAN</span>
            </>
          }
        />

        <div className="mt-14 grid items-start gap-8 lg:grid-cols-[0.85fr_1.15fr] lg:gap-12">
          {/* Profile card with honest photo placeholder */}
          <Reveal>
            <div className="card-border-glow rounded-3xl border border-white/[0.07] bg-card/70 p-8 text-center sm:p-10">
              {/* Photo placeholder — intentionally not a generated photograph */}
              <div className="relative mx-auto h-40 w-40">
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-electric-400 via-electric-600 to-electric-300 opacity-80 blur-[2px]" aria-hidden />
                <div className="relative flex h-40 w-40 items-center justify-center overflow-hidden rounded-full border-4 border-[#0b0e16] bg-[#0e1322]">
                  <span className="font-display text-5xl font-bold tracking-wide text-white">
                    KM
                  </span>
                </div>
                <span className="absolute bottom-1 right-1 flex h-9 w-9 items-center justify-center rounded-full border-4 border-[#0b0e16] bg-electric-500" aria-hidden>
                  <UserRound className="h-4 w-4 text-white" />
                </span>
              </div>
              <p className="mt-3 text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                Founder photo coming soon
              </p>

              <h3 className="mt-4 font-display text-2xl font-bold text-white">Khushal Mahajan</h3>
              <p className="mt-1.5 text-sm font-semibold uppercase tracking-[0.18em] text-electric-400">
                Founder &amp; Web Developer
              </p>

              <dl className="mt-7 space-y-3.5 text-left">
                {FACTS.map((fact) => (
                  <div key={fact.label} className="flex items-start gap-3">
                    <span className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-electric-500/10 border border-electric-500/20">
                      <fact.icon className="h-4 w-4 text-electric-400" aria-hidden />
                    </span>
                    <div>
                      <dt className="text-[11px] uppercase tracking-[0.14em] text-muted-foreground">
                        {fact.label}
                      </dt>
                      <dd className="text-sm font-medium text-foreground">{fact.value}</dd>
                    </div>
                  </div>
                ))}
              </dl>

              <Button
                asChild
                variant="outline"
                className="mt-8 w-full rounded-full border-white/15 bg-white/[0.03] font-semibold text-white hover:border-electric-500/60 hover:bg-electric-500/10 hover:text-white"
              >
                <a href="mailto:brainboltoffical@gmail.com">
                  <Mail className="mr-2 h-4 w-4" aria-hidden />
                  Email Khushal Directly
                </a>
              </Button>
            </div>
          </Reveal>

          {/* Biography */}
          <Reveal delay={0.15}>
            <div className="flex h-full flex-col justify-between gap-8">
              <div className="space-y-5">
                <p className="font-display text-xl font-medium leading-relaxed text-white sm:text-2xl">
                  Hello! I&apos;m Khushal Mahajan, founder of MAHAJAN Web Development Studio.
                </p>
                <p className="text-[15px] leading-relaxed text-muted-foreground sm:text-base">
                  I am a second-year B.Tech student specializing in Artificial Intelligence and Data
                  Science. I am passionate about website design, modern technologies and creating
                  professional digital experiences for businesses.
                </p>
                <p className="text-[15px] leading-relaxed text-muted-foreground sm:text-base">
                  Through MAHAJAN, I aim to help small businesses establish a strong online presence
                  with modern, responsive and user-friendly websites — the kind of websites that
                  build trust from the very first visit.
                </p>
                <p className="text-[15px] leading-relaxed text-muted-foreground sm:text-base">
                  As a student founder, I bring fresh knowledge of the latest web technologies,
                  genuine attention to every project and honest, clear communication — without
                  agency overheads. You work directly with the person building your website.
                </p>
              </div>

              {/* Mission card */}
              <div className="relative overflow-hidden rounded-2xl border border-electric-500/25 bg-gradient-to-br from-electric-600/15 via-card to-card p-7 sm:p-8">
                <div className="absolute -right-6 -top-6 opacity-[0.08]" aria-hidden>
                  <Monogram className="h-36 w-36" />
                </div>
                <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-electric-400">
                  Our Promise
                </p>
                <p className="mt-3 font-display text-2xl font-bold text-white sm:text-[1.7rem]">
                  &ldquo;Websites That Build Your Business.&rdquo;
                </p>
                <p className="mt-3 max-w-lg text-sm leading-relaxed text-muted-foreground">
                  Modern design, honest communication and reliable delivery — every website is
                  built as if it were our own business on the line.
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
