import { Mail, MapPin, Phone } from "lucide-react";
import { Logo } from "@/components/brand/Logo";

const QUICK_LINKS = [
  { label: "Home", href: "#home" },
  { label: "Services", href: "#services" },
  { label: "Our Work", href: "#work" },
  { label: "Process", href: "#process" },
  { label: "About the Founder", href: "#about" },
  { label: "Contact", href: "#contact" },
];

const SERVICE_LINKS = [
  "Business Website Development",
  "E-commerce Website Development",
  "Shopify Store Design",
  "Website Redesign",
  "Responsive Website Design",
  "Landing Page Development",
];

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto border-t border-white/[0.07] bg-[#07080d]" aria-label="Footer">
      <div className="mx-auto w-full max-w-7xl px-5 py-14 sm:px-8 lg:py-16">
        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          {/* Brand */}
          <div>
            <Logo />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-muted-foreground">
              A web development studio helping small businesses build a strong digital presence
              with modern, responsive and professional websites.
            </p>
            <p className="mt-4 font-display text-sm font-semibold tracking-wide text-electric-400">
              Websites That Build Your Business.
            </p>
          </div>

          {/* Navigation */}
          <nav aria-label="Footer navigation">
            <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-white">
              Navigation
            </h3>
            <ul className="mt-5 space-y-3">
              {QUICK_LINKS.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-electric-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          {/* Services */}
          <div>
            <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-white">
              Services
            </h3>
            <ul className="mt-5 space-y-3">
              {SERVICE_LINKS.map((service) => (
                <li key={service}>
                  <a
                    href="#services"
                    className="text-sm text-muted-foreground transition-colors hover:text-electric-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded"
                  >
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-display text-sm font-semibold uppercase tracking-[0.2em] text-white">
              Contact
            </h3>
            <ul className="mt-5 space-y-4">
              <li>
                <a
                  href="mailto:brainboltoffical@gmail.com"
                  className="flex items-start gap-3 text-sm text-muted-foreground transition-colors hover:text-electric-400"
                >
                  <Mail className="mt-0.5 h-4 w-4 shrink-0 text-electric-400" aria-hidden />
                  <span className="break-all">brainboltoffical@gmail.com</span>
                </a>
              </li>
              <li>
                <a
                  href="tel:+917499001739"
                  className="flex items-start gap-3 text-sm text-muted-foreground transition-colors hover:text-electric-400"
                >
                  <Phone className="mt-0.5 h-4 w-4 shrink-0 text-electric-400" aria-hidden />
                  +91 74990 01739
                </a>
              </li>
              <li className="flex items-start gap-3 text-sm text-muted-foreground">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-electric-400" aria-hidden />
                Pune, Maharashtra, India
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/[0.07] pt-8 sm:flex-row">
          <div className="text-center sm:text-left">
            <p className="text-xs leading-relaxed text-muted-foreground">
              © {year} MAHAJAN Web Development Studio. All rights reserved.
            </p>
            <p className="mt-1.5 text-[11px] leading-relaxed text-muted-foreground/60">
              Privacy-first website — cookieless analytics, no personal data collected.
            </p>
          </div>
          <div className="flex items-center gap-4">
            <p className="text-xs text-muted-foreground">
              Founded by <span className="font-medium text-foreground">Khushal Mahajan</span> · Pune,
              India
            </p>
            {/* Discreet admin access — security never depends on this link staying hidden */}
            <a
              href="/admin/login"
              aria-label="MS — administrator sign in"
              title="MS"
              className="rounded px-1 text-[10px] font-medium tracking-wide text-white/20 transition-colors hover:text-electric-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              MS
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
