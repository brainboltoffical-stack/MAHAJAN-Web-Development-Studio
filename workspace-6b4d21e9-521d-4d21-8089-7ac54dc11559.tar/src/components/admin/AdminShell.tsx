"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  BarChart3,
  Inbox,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings,
  ShieldCheck,
} from "lucide-react";
import { Logo } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { adminFetch } from "@/lib/admin/client";

const NAV_ITEMS = [
  { label: "Overview", href: "/admin", icon: LayoutDashboard },
  { label: "Messages", href: "/admin/messages", icon: Inbox, badge: "unread" as const },
  { label: "Analytics", href: "/admin/analytics", icon: BarChart3 },
  { label: "Settings", href: "/admin/settings", icon: Settings },
];

export function AdminShell({
  admin,
  children,
}: {
  /** Only the owner's public business email is shown — never the admin username. */
  admin: { email: string };
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [unread, setUnread] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    let active = true;
    const load = () =>
      adminFetch<{ unread: number }>("/api/admin/badge")
        .then((d) => active && setUnread(d.unread))
        .catch(() => undefined);
    load();
    const interval = setInterval(load, 60_000);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, [pathname]);

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await adminFetch("/api/admin/logout", { method: "POST" });
    } catch {
      /* session already gone */
    }
    router.replace("/admin/login");
    router.refresh();
  };

  const renderNavLinks = (onNavigate?: () => void) => (
    <nav aria-label="Admin navigation" className="flex flex-1 flex-col gap-1.5">
      {NAV_ITEMS.map((item) => {
        const active = item.href === "/admin" ? pathname === "/admin" : pathname.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
              active
                ? "bg-electric-500/15 text-electric-300 border border-electric-500/30"
                : "text-muted-foreground border border-transparent hover:bg-white/[0.04] hover:text-white"
            )}
          >
            <item.icon className="h-[18px] w-[18px] shrink-0" aria-hidden />
            <span className="flex-1">{item.label}</span>
            {item.badge === "unread" && unread > 0 && (
              <span className="rounded-full bg-electric-500 px-2 py-0.5 text-[10.5px] font-bold leading-none text-white">
                {unread}
              </span>
            )}
          </Link>
        );
      })}
    </nav>
  );

  const renderSidebarFooter = () => (
    <div className="space-y-4 border-t border-white/[0.07] pt-5">
      <div className="flex items-center gap-3 px-1">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-electric-400 to-electric-600">
          <ShieldCheck className="h-4 w-4 text-white" aria-hidden />
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold text-white">Administrator</p>
          <p className="truncate text-[11px] text-muted-foreground">{admin.email}</p>
        </div>
      </div>
      <Button
        onClick={handleLogout}
        disabled={loggingOut}
        variant="outline"
        className="w-full rounded-xl border-white/10 bg-white/[0.03] text-sm font-medium text-foreground hover:border-red-500/40 hover:bg-red-500/10 hover:text-red-300"
      >
        <LogOut className="mr-2 h-4 w-4" aria-hidden />
        {loggingOut ? "Signing out…" : "Logout"}
      </Button>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[#05060B] text-foreground">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[260px] flex-col border-r border-white/[0.07] bg-[#080a10] px-5 py-6 lg:flex">
        <Link href="/admin" className="mb-8 rounded-lg px-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
          <Logo monogramClassName="h-9 w-9" />
        </Link>
        {renderNavLinks()}
        {renderSidebarFooter()}
      </aside>

      {/* Mobile top bar */}
      <div className="fixed inset-x-0 top-0 z-40 flex h-16 items-center justify-between border-b border-white/[0.07] glass px-4 lg:hidden">
        <Link href="/admin" className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-lg">
          <Logo monogramClassName="h-8 w-8" />
        </Link>
        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger asChild>
            <Button
              variant="outline"
              size="icon"
              className="rounded-lg border-white/15 bg-white/5 text-white hover:bg-white/10 hover:text-white"
              aria-label="Open admin menu"
            >
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[280px] border-white/10 bg-[#080a10] px-5 py-6">
            <SheetTitle asChild>
              <div className="mb-8">
                <Logo monogramClassName="h-9 w-9" />
              </div>
            </SheetTitle>
            <div className="flex h-[calc(100%-6rem)] flex-col">
              {renderNavLinks(() => setMenuOpen(false))}
              {renderSidebarFooter()}
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Main content */}
      <main className="min-h-screen w-full flex-1 px-5 pb-16 pt-20 sm:px-8 lg:ml-[260px] lg:px-10 lg:pt-9">
        <div className="mx-auto w-full max-w-6xl">{children}</div>
        <p className="mx-auto mt-12 flex w-full max-w-6xl items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
          <ShieldCheck className="h-3 w-3 text-electric-500/70" aria-hidden />
          Server-verified admin session · activity is logged
        </p>
      </main>
    </div>
  );
}
