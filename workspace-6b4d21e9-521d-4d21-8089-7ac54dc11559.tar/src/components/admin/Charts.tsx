"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const ELECTRIC = "#2e7cff";
const ELECTRIC_LIGHT = "#8ab6ff";
const CYAN = "#6fd2ff";
const GRID = "rgba(255,255,255,0.07)";
const TICK = { fill: "#97a0b5", fontSize: 11 };

const tooltipStyle = {
  backgroundColor: "#0d1019",
  border: "1px solid rgba(255,255,255,0.12)",
  borderRadius: 12,
  color: "#f4f6fb",
  fontSize: 12.5,
};

const DEVICE_COLORS: Record<string, string> = {
  Desktop: ELECTRIC,
  Mobile: CYAN,
  Tablet: ELECTRIC_LIGHT,
};

export function VisitorsTrendChart({
  data,
}: {
  data: { date: string; visitors: number; views: number }[];
}) {
  return (
    <div className="h-[280px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }}>
          <defs>
            <linearGradient id="electricFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={ELECTRIC} stopOpacity={0.45} />
              <stop offset="100%" stopColor={ELECTRIC} stopOpacity={0.02} />
            </linearGradient>
            <linearGradient id="cyanFill" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={CYAN} stopOpacity={0.3} />
              <stop offset="100%" stopColor={CYAN} stopOpacity={0.02} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke={GRID} vertical={false} />
          <XAxis dataKey="date" tick={TICK} tickLine={false} axisLine={{ stroke: GRID }} />
          <YAxis tick={TICK} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip contentStyle={tooltipStyle} cursor={{ stroke: "rgba(46,124,255,0.4)" }} />
          <Legend wrapperStyle={{ fontSize: 12, color: "#97a0b5" }} />
          <Area
            type="monotone"
            dataKey="views"
            name="Page views"
            stroke={CYAN}
            strokeWidth={2}
            fill="url(#cyanFill)"
          />
          <Area
            type="monotone"
            dataKey="visitors"
            name="Visitors"
            stroke={ELECTRIC}
            strokeWidth={2}
            fill="url(#electricFill)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}

export function MonthlyTrendChart({
  data,
}: {
  data: { month: string; visitors: number; views: number }[];
}) {
  return (
    <div className="h-[260px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 8, left: -18, bottom: 0 }} barGap={4}>
          <CartesianGrid stroke={GRID} vertical={false} />
          <XAxis dataKey="month" tick={TICK} tickLine={false} axisLine={{ stroke: GRID }} />
          <YAxis tick={TICK} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(46,124,255,0.08)" }} />
          <Legend wrapperStyle={{ fontSize: 12, color: "#97a0b5" }} />
          <Bar dataKey="views" name="Page views" fill={CYAN} radius={[5, 5, 0, 0]} maxBarSize={34} />
          <Bar dataKey="visitors" name="Visitors" fill={ELECTRIC} radius={[5, 5, 0, 0]} maxBarSize={34} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export function DeviceDonut({ data }: { data: { device: string; count: number }[] }) {
  return (
    <div className="h-[240px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="count"
            nameKey="device"
            innerRadius="55%"
            outerRadius="80%"
            paddingAngle={3}
            stroke="none"
          >
            {data.map((entry) => (
              <Cell key={entry.device} fill={DEVICE_COLORS[entry.device] ?? ELECTRIC} />
            ))}
          </Pie>
          <Tooltip contentStyle={tooltipStyle} />
          <Legend wrapperStyle={{ fontSize: 12, color: "#97a0b5" }} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}

export function TopPagesChart({ data }: { data: { path: string; views: number }[] }) {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} layout="vertical" margin={{ top: 4, right: 16, left: 8, bottom: 0 }}>
          <CartesianGrid stroke={GRID} horizontal={false} />
          <XAxis type="number" tick={TICK} tickLine={false} axisLine={{ stroke: GRID }} allowDecimals={false} />
          <YAxis
            type="category"
            dataKey="path"
            tick={{ ...TICK, fontSize: 11 }}
            tickLine={false}
            axisLine={false}
            width={150}
          />
          <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(46,124,255,0.08)" }} />
          <Bar dataKey="views" name="Views" fill={ELECTRIC} radius={[0, 5, 5, 0]} maxBarSize={22} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

/** Simple labelled bar rows for sources / countries. */
export function BarList({
  items,
  emptyLabel,
}: {
  items: { label: string; count: number }[];
  emptyLabel: string;
}) {
  if (items.length === 0) {
    return <p className="py-6 text-center text-[12.5px] text-muted-foreground">{emptyLabel}</p>;
  }
  const max = Math.max(...items.map((i) => i.count));
  return (
    <ul className="space-y-3">
      {items.map((item) => (
        <li key={item.label}>
          <div className="mb-1.5 flex items-center justify-between text-[12.5px]">
            <span className="truncate text-foreground/85">{item.label}</span>
            <span className="ml-3 shrink-0 font-medium text-muted-foreground">{item.count}</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
            <div
              className="h-full rounded-full bg-gradient-to-r from-electric-600 to-electric-400"
              style={{ width: `${Math.max(4, (item.count / max) * 100)}%` }}
            />
          </div>
        </li>
      ))}
    </ul>
  );
}
