"use client";

import { cn } from "@/lib/utils";

export function PageHeader({
  title,
  subtitle,
  actions,
}: {
  title: string;
  subtitle?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">{title}</h1>
        {subtitle && <p className="mt-1.5 text-sm text-muted-foreground">{subtitle}</p>}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2.5">{actions}</div>}
    </div>
  );
}

export function StatCard({
  label,
  value,
  icon: Icon,
  hint,
  accent = "electric",
}: {
  label: string;
  value: number | string;
  icon: React.ComponentType<{ className?: string }>;
  hint?: string;
  accent?: "electric" | "white" | "green" | "amber";
}) {
  const accents: Record<string, string> = {
    electric: "from-electric-400 to-electric-600 shadow-[0_10px_30px_-10px_rgba(46,124,255,0.6)]",
    white: "from-slate-300 to-slate-500 shadow-[0_10px_30px_-10px_rgba(148,163,184,0.4)]",
    green: "from-emerald-400 to-emerald-600 shadow-[0_10px_30px_-10px_rgba(16,185,129,0.5)]",
    amber: "from-amber-400 to-orange-500 shadow-[0_10px_30px_-10px_rgba(245,158,11,0.5)]",
  };
  return (
    <div className="card-border-glow rounded-2xl border border-white/[0.07] bg-card/70 p-5 transition-colors hover:border-electric-500/25">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase leading-snug tracking-[0.12em] text-muted-foreground">
            {label}
          </p>
          <p className="mt-2 font-display text-3xl font-bold leading-none text-white">
            {typeof value === "number" ? value.toLocaleString("en-IN") : value}
          </p>
          {hint && <p className="mt-2 text-[11.5px] leading-snug text-muted-foreground">{hint}</p>}
        </div>
        <span
          className={cn(
            "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br",
            accents[accent]
          )}
        >
          <Icon className="h-5 w-5 text-white" aria-hidden />
        </span>
      </div>
    </div>
  );
}

export function Panel({
  title,
  subtitle,
  children,
  className,
  action,
}: {
  title?: string;
  subtitle?: string;
  children: React.ReactNode;
  className?: string;
  action?: React.ReactNode;
}) {
  return (
    <section className={cn("rounded-2xl border border-white/[0.07] bg-card/70 p-5 sm:p-6", className)}>
      {(title || action) && (
        <div className="mb-5 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="font-display text-base font-semibold text-white">{title}</h2>}
            {subtitle && <p className="mt-1 text-[12.5px] text-muted-foreground">{subtitle}</p>}
          </div>
          {action}
        </div>
      )}
      {children}
    </section>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  message,
}: {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  message: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-white/10 px-6 py-12 text-center">
      <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-electric-500/10 border border-electric-500/20">
        <Icon className="h-5 w-5 text-electric-400" aria-hidden />
      </span>
      <p className="mt-4 font-display text-sm font-semibold text-white">{title}</p>
      <p className="mt-1.5 max-w-sm text-[12.5px] leading-relaxed text-muted-foreground">{message}</p>
    </div>
  );
}

export function LoadingBlock({ label = "Loading live data…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-16 text-sm text-muted-foreground">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-electric-500/30 border-t-electric-400" aria-hidden />
      {label}
    </div>
  );
}

export function ErrorBlock({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-red-500/25 bg-red-500/[0.06] px-6 py-10 text-center">
      <p className="text-sm text-red-300">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="mt-4 rounded-full border border-white/15 px-4 py-1.5 text-xs font-medium text-white hover:border-electric-500/50 hover:text-electric-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
        >
          Try again
        </button>
      )}
    </div>
  );
}

export const STATUS_STYLES: Record<string, string> = {
  New: "bg-electric-500/15 text-electric-300 border-electric-500/30",
  Contacted: "bg-sky-500/10 text-sky-300 border-sky-500/30",
  "In Discussion": "bg-amber-500/10 text-amber-300 border-amber-500/30",
  Completed: "bg-emerald-500/10 text-emerald-300 border-emerald-500/30",
};

export const STATUS_LIST = ["New", "Contacted", "In Discussion", "Completed"];

export function formatIstDateTime(iso: string | Date): string {
  const date = typeof iso === "string" ? new Date(iso) : iso;
  return date.toLocaleString("en-IN", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}
