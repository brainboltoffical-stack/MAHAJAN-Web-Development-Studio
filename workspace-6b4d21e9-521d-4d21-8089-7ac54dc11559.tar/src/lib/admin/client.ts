"use client";

/**
 * Same-origin admin API client.
 * - attaches the custom CSRF header required by every mutating admin endpoint
 * - transparently redirects to the login page when the session is gone (401)
 */
export async function adminFetch<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      "x-mahajan-admin": "1",
      ...(init?.headers ?? {}),
    },
  });

  if (res.status === 401) {
    window.location.href = "/admin/login?expired=1";
    throw new Error("Session expired");
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error((data as { error?: string }).error || `Request failed (${res.status})`);
  }
  return data as T;
}
