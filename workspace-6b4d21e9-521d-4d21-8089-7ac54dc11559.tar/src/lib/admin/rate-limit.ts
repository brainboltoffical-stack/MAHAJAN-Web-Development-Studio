/**
 * In-memory sliding-window rate limiting + login lockout.
 *
 * Suitable for the single-instance sandbox/preview. For a multi-instance
 * production deployment, back this with Redis (documented in Settings).
 * Persistent evidence of failed attempts is also kept in the LoginAttempt
 * table, so monitoring survives restarts even though the live counter resets.
 *
 * Thresholds: login 20 req/15min per IP; lockout 5 failures/15min;
 * inquiries 5/hour per IP; tracking 30/min per IP.
 */

type SlidingWindow = { hits: number[] };

const windows = new Map<string, SlidingWindow>();
const loginFailures = new Map<string, number[]>();

// Periodically clean stale entries to avoid unbounded growth.
function prune(map: Map<string, number[]>, windowMs: number) {
  const now = Date.now();
  for (const [key, hits] of map) {
    const fresh = hits.filter((t) => now - t < windowMs);
    if (fresh.length === 0) map.delete(key);
    else map.set(key, fresh);
  }
}

/** Generic fixed-memory sliding window. Returns true when the request is allowed. */
export function rateLimit(key: string, limit: number, windowMs: number): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  const entry = windows.get(key) ?? { hits: [] };
  entry.hits = entry.hits.filter((t) => now - t < windowMs);
  if (entry.hits.length >= limit) {
    windows.set(key, entry);
    const retryAfterSec = Math.ceil((entry.hits[0] + windowMs - now) / 1000);
    return { allowed: false, retryAfterSec };
  }
  entry.hits.push(now);
  windows.set(key, entry);
  return { allowed: true, retryAfterSec: 0 };
}

/* ------------------------------ login lockout ------------------------------ */

export const LOGIN_MAX_FAILURES = 5;
export const LOGIN_LOCKOUT_MS = 15 * 60 * 1000; // 15 minutes

export function loginFailureKey(identifier: string, ip: string): string {
  return `${identifier.toLowerCase()}::${ip}`;
}

export function recordLoginFailure(key: string): void {
  const now = Date.now();
  const hits = (loginFailures.get(key) ?? []).filter((t) => now - t < LOGIN_LOCKOUT_MS);
  hits.push(now);
  loginFailures.set(key, hits);
}

export function isLockedOut(key: string): { locked: boolean; retryAfterSec: number; failures: number } {
  const now = Date.now();
  const hits = (loginFailures.get(key) ?? []).filter((t) => now - t < LOGIN_LOCKOUT_MS);
  if (hits.length < LOGIN_MAX_FAILURES) return { locked: false, retryAfterSec: 0, failures: hits.length };
  return {
    locked: true,
    retryAfterSec: Math.max(1, Math.ceil((hits[0] + LOGIN_LOCKOUT_MS - now) / 1000)),
    failures: hits.length,
  };
}

export function resetLoginFailures(key: string): void {
  loginFailures.delete(key);
}

/** Admin-facing: clear every active lockout (fail2ban-style manual unban). */
export function clearAllLockouts(): number {
  const count = loginFailures.size;
  loginFailures.clear();
  prune(loginFailures, LOGIN_LOCKOUT_MS);
  return count;
}
