/**
 * Privacy-first visitor tracking helpers.
 *
 * - No cookies, no localStorage, no personal data.
 * - Visitors are pseudonymised: one-way SHA-256 hashes of (IP + user agent),
 *   salted with a server-side pepper and rotated daily / monthly.
 * - Raw IP addresses are never stored.
 * - Bots and preview/monitoring agents are excluded.
 * - Browser "Do Not Track" is respected (client-side + server-side header check).
 */
import { createHash } from "node:crypto";

const PEPPER = () => process.env.AUTH_SECRET || "mahajan-tracking-pepper";

export const IST_OFFSET_MIN = 330;

/** Start of the current day in India Standard Time, as a UTC Date. */
export function istDayStart(reference = new Date()): Date {
  const shifted = new Date(reference.getTime() + IST_OFFSET_MIN * 60000);
  shifted.setUTCHours(0, 0, 0, 0);
  return new Date(shifted.getTime() - IST_OFFSET_MIN * 60000);
}

function istKey(reference: Date, granularity: "day" | "month"): string {
  const shifted = new Date(reference.getTime() + IST_OFFSET_MIN * 60000);
  const y = shifted.getUTCFullYear();
  const m = String(shifted.getUTCMonth() + 1).padStart(2, "0");
  const d = String(shifted.getUTCDate()).padStart(2, "0");
  return granularity === "day" ? `${y}-${m}-${d}` : `${y}-${m}`;
}

export function visitorHashes(ip: string | null, userAgent: string | null, now = new Date()) {
  const base = `${ip ?? "unknown"}|${userAgent ?? "unknown"}|${PEPPER()}`;
  return {
    visitorDaily: createHash("sha256").update(`vd:${istKey(now, "day")}:${base}`).digest("hex").slice(0, 24),
    visitorMonthly: createHash("sha256").update(`vm:${istKey(now, "month")}:${base}`).digest("hex").slice(0, 24),
  };
}

const BOT_PATTERN =
  /bot|crawl|spider|slurp|headless|chrome-lighthouse|phantom|curl|wget|python|java\/|okhttp|axios|postman|insomnia|pingdom|uptimerobot|monitor|preview-generator/i;

export function isBot(userAgent: string | null): boolean {
  if (!userAgent || userAgent.trim().length < 10) return true;
  return BOT_PATTERN.test(userAgent);
}

export function detectDevice(userAgent: string | null): "Desktop" | "Mobile" | "Tablet" {
  if (!userAgent) return "Desktop";
  if (/iPad|Tablet|PlayBook|Silk|(Android(?!.*Mobile))/i.test(userAgent)) return "Tablet";
  if (/Mobi|iPhone|iPod|Android.*Mobile|Windows Phone|BlackBerry|Opera Mini/i.test(userAgent)) return "Mobile";
  return "Desktop";
}

const SEARCH_ENGINES = ["google", "bing", "duckduckgo", "yahoo", "baidu", "yandex", "ecosia", "brave"];
const SOCIAL = [
  "instagram", "facebook", "x.com", "twitter", "linkedin", "whatsapp", "telegram",
  "pinterest", "youtube", "reddit", "tiktok", "threads",
];
const AI_TOOLS = ["chatgpt", "openai", "perplexity", "claude", "gemini", "copilot", "poe", "mistral"];

export type TrafficSource = "Direct" | "Search engines" | "Social" | "AI assistants" | "Referral";

export function classifyReferrer(referrer: string | null): { source: TrafficSource; domain: string | null } {
  if (!referrer) return { source: "Direct", domain: null };
  try {
    const url = new URL(referrer);
    const domain = url.hostname.replace(/^www\./, "").toLowerCase();
    if (SEARCH_ENGINES.some((s) => domain.includes(s))) return { source: "Search engines", domain };
    if (SOCIAL.some((s) => domain.includes(s))) return { source: "Social", domain };
    if (AI_TOOLS.some((s) => domain.includes(s))) return { source: "AI assistants", domain };
    return { source: "Referral", domain };
  } catch {
    return { source: "Referral", domain: null };
  }
}

/** Country from edge/CDN geo headers — only when the platform provides them. */
export function detectCountry(headers: Headers): string | null {
  const code =
    headers.get("x-vercel-ip-country") ??
    headers.get("cf-ipcountry") ??
    headers.get("x-geolocation-country") ??
    headers.get("x-country-code");
  if (!code || code === "XX" || code.length !== 2) return null;
  return code.toUpperCase();
}

/** Sanitise a path for storage (no query strings, capped length). */
export function normalisePath(raw: string | undefined | null): string | null {
  if (!raw || typeof raw !== "string") return null;
  let path = raw.trim();
  if (path.length > 300) path = path.slice(0, 300);
  try {
    const url = new URL(path, "http://x");
    path = url.pathname;
    if (url.hash) path += url.hash.slice(0, 60);
  } catch {
    /* keep raw */
  }
  if (!path.startsWith("/") || path.startsWith("/admin") || path.startsWith("/api")) return null;
  return path.slice(0, 200);
}
