"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Loader2, Lock, ShieldCheck, UserRound } from "lucide-react";
import { Logo, Monogram } from "@/components/brand/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function AdminLoginPage() {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error || "Invalid credentials. All attempts are logged.");
        return;
      }
      router.replace("/admin");
      router.refresh();
    } catch {
      setError("Login is temporarily unavailable. Please try again.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-[#05060B] px-5 py-12">
      <div className="bg-grid bg-grid-fade absolute inset-0" aria-hidden />
      <div
        className="absolute left-1/2 top-1/3 h-[420px] w-[640px] -translate-x-1/2 rounded-full bg-electric-600/15 blur-[130px]"
        aria-hidden
      />

      <div className="relative w-full max-w-md">
        <div className="mb-8 flex justify-center">
          <a href="/" aria-label="Back to MAHAJAN website" className="rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            <Logo />
          </a>
        </div>

        <div className="card-border-glow rounded-3xl border border-white/[0.08] bg-card/80 p-8 shadow-[0_40px_120px_-40px_rgba(0,0,0,0.9)] sm:p-10">
          <div className="mb-8 text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl border border-electric-500/30 bg-electric-500/10">
              <Lock className="h-6 w-6 text-electric-400" aria-hidden />
            </div>
            <h1 className="mt-5 font-display text-2xl font-bold text-white">Admin Sign In</h1>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              Secure area — authorised administrators only.
            </p>
          </div>

          {error && (
            <div
              role="alert"
              className="mb-5 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300"
            >
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="identifier" className="text-sm text-foreground">
                Username or Email
              </Label>
              <div className="relative">
                <UserRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
                <Input
                  id="identifier"
                  name="identifier"
                  autoComplete="username"
                  placeholder="Admin username"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  className="h-11 border-white/10 bg-white/[0.04] pl-10 text-white placeholder:text-muted-foreground/50 focus-visible:border-electric-500/60"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm text-foreground">
                Password
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="••••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="h-11 border-white/10 bg-white/[0.04] pr-11 text-white placeholder:text-muted-foreground/50 focus-visible:border-electric-500/60"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded p-1 text-muted-foreground transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              disabled={submitting || !identifier || !password}
              className="glow-electric h-12 w-full rounded-full bg-electric-500 text-[15px] font-semibold text-white hover:bg-electric-600 disabled:opacity-60"
            >
              {submitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden />
                  Verifying…
                </>
              ) : (
                "Sign In Securely"
              )}
            </Button>
          </form>

          <div className="mt-7 space-y-2.5 border-t border-white/[0.07] pt-6">
            <p className="flex items-center gap-2 text-[12px] leading-relaxed text-muted-foreground">
              <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-electric-400" aria-hidden />
              Protected by rate limiting — repeated failed attempts lock the account temporarily.
            </p>
            <p className="flex items-center gap-2 text-[12px] leading-relaxed text-muted-foreground">
              <Monogram className="h-4 w-4 shrink-0" aria-hidden />
              There is no public registration. Every login attempt is recorded.
            </p>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          <a href="/" className="rounded transition-colors hover:text-electric-400 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
            ← Back to the website
          </a>
        </p>
      </div>
    </div>
  );
}
