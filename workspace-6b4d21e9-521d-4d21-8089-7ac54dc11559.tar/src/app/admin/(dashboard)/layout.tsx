import type { Metadata } from "next";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { getSessionContext, SESSION_COOKIE } from "@/lib/admin/auth";
import { AdminShell } from "@/components/admin/AdminShell";

export const metadata: Metadata = {
  title: "MAHAJAN Admin",
  robots: { index: false, follow: false },
};

/**
 * Server-side gate: every /admin page render verifies the session against the
 * database before any dashboard content is produced. Unauthenticated visitors
 * are redirected to the secure login page.
 */
export default async function AdminDashboardLayout({ children }: { children: React.ReactNode }) {
  const store = await cookies();
  const ctx = await getSessionContext(store.get(SESSION_COOKIE)?.value);
  if (!ctx) redirect("/admin/login");

  return <AdminShell admin={ctx.admin}>{children}</AdminShell>;
}
