"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  AlertTriangle,
  CalendarDays,
  CalendarRange,
  Eye,
  Inbox,
  MonitorSmartphone,
  TrendingUp,
  UserCheck,
  Users,
} from "lucide-react";
import { PageHeader, Panel, StatCard, EmptyState, LoadingBlock, ErrorBlock, STATUS_STYLES, formatIstDateTime } from "@/components/admin/ui-bits";
import { VisitorsTrendChart } from "@/components/admin/Charts";
import { adminFetch } from "@/lib/admin/client";

type Overview = {
  stats: {
    totalVisitors: number;
    uniqueVisitors: number;
    totalPageViews: number;
    todayVisitors: number;
    weekVisitors: number;
    monthVisitors: number;
    totalInquiries: number;
    unreadMessages: number;
  };
  trend: { date: string; visitors: number; views: number }[];
  statusCounts: Record<string, number>;
  recentMessages: {
    id: string;
    name: string;
    email: string;
    websiteType: string;
    status: string;
    isRead: boolean;
    createdAt: string;
  }[];
  security: { failedAttempts15m: number; alert: boolean };
};

export default function AdminOverviewPage() {
  const [data, setData] = useState<Overview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    adminFetch<Overview>("/api/admin/overview")
      .then(setData)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const t = setTimeout(load, 0);
    return () => clearTimeout(t);
  }, [load]);

  return (
    <>
      <PageHeader
        title="Overview"
        subtitle="Live website statistics — every number on this page is computed from real data."
      />

      {data?.security.alert && (
        <div className="mb-6 flex items-start gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/[0.08] px-5 py-4">
          <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" aria-hidden />
          <div className="text-sm">
            <p className="font-semibold text-amber-200">Suspicious login activity detected</p>
            <p className="mt-1 leading-relaxed text-amber-200/80">
              {data.security.failedAttempts15m} failed admin login attempts in the last 15 minutes. Review
              Settings → Login activity. Accounts are automatically locked after 5 failures.
            </p>
          </div>
        </div>
      )}

      {loading ? (
        <LoadingBlock />
      ) : error ? (
        <ErrorBlock message={error} onRetry={load} />
      ) : data ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Total Website Visitors" value={data.stats.totalVisitors} icon={Users} hint="All-time visit sessions" />
            <StatCard label="Unique Visitors" value={data.stats.uniqueVisitors} icon={UserCheck} hint="Pseudonymous, privacy-first" accent="white" />
            <StatCard label="Total Page Views" value={data.stats.totalPageViews} icon={Eye} hint="All pages, all time" accent="white" />
            <StatCard label="Contact Form Submissions" value={data.stats.totalInquiries} icon={Inbox} hint="All enquiries received" />
          </div>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Today's Visitors" value={data.stats.todayVisitors} icon={CalendarDays} hint="Since midnight IST" />
            <StatCard label="This Week's Visitors" value={data.stats.weekVisitors} icon={TrendingUp} hint="Rolling 7 days" />
            <StatCard label="This Month's Visitors" value={data.stats.monthVisitors} icon={CalendarRange} hint="Current calendar month (IST)" />
            <StatCard
              label="Unread Messages"
              value={data.stats.unreadMessages}
              icon={Inbox}
              accent={data.stats.unreadMessages > 0 ? "amber" : "green"}
              hint={data.stats.unreadMessages > 0 ? "Awaiting your reply" : "Inbox is up to date"}
            />
          </div>

          <Panel
            title="Visitors — last 14 days"
            subtitle="Daily visitors and page views (IST days). Chart appears as real traffic arrives."
          >
            {data.trend.some((d) => d.views > 0) ? (
              <VisitorsTrendChart data={data.trend} />
            ) : (
              <EmptyState
                icon={MonitorSmartphone}
                title="No traffic recorded yet"
                message="Live visitor statistics appear here as soon as real visitors browse the website. Nothing is simulated."
              />
            )}
          </Panel>

          <Panel
            title="Recent enquiries"
            subtitle="The five latest contact form submissions."
            action={
              <Link
                href="/admin/messages"
                className="rounded-full border border-white/10 px-3.5 py-1.5 text-xs font-medium text-electric-300 transition-colors hover:border-electric-500/40 hover:text-electric-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
              >
                Open inbox
              </Link>
            }
          >
            {data.recentMessages.length === 0 ? (
              <EmptyState
                icon={Inbox}
                title="No enquiries yet"
                message="When visitors submit the contact form, their messages appear here and in the Messages inbox."
              />
            ) : (
              <ul className="divide-y divide-white/[0.06]">
                {data.recentMessages.map((m) => (
                  <li key={m.id} className="flex flex-wrap items-center gap-x-4 gap-y-1.5 py-3.5 first:pt-0 last:pb-0">
                    <span className={`h-2 w-2 shrink-0 rounded-full ${m.isRead ? "bg-white/20" : "bg-electric-400"}`} aria-label={m.isRead ? "Read" : "Unread"} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium text-white">
                        {m.name}
                        <span className="ml-2 text-[12px] font-normal text-muted-foreground">{m.email}</span>
                      </p>
                      <p className="truncate text-[12px] text-muted-foreground">
                        {m.websiteType} · {formatIstDateTime(m.createdAt)}
                      </p>
                    </div>
                    <span className={`rounded-full border px-2.5 py-1 text-[10.5px] font-semibold ${STATUS_STYLES[m.status] ?? ""}`}>
                      {m.status}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </Panel>

          <Panel title="Enquiry pipeline" subtitle="Where your enquiries currently stand.">
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              {(["New", "Contacted", "In Discussion", "Completed"] as const).map((status) => (
                <div key={status} className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 text-center">
                  <p className="font-display text-2xl font-bold text-white">{data.statusCounts[status] ?? 0}</p>
                  <span className={`mt-2 inline-block rounded-full border px-2.5 py-0.5 text-[10.5px] font-semibold ${STATUS_STYLES[status]}`}>
                    {status}
                  </span>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      ) : null}
    </>
  );
}
