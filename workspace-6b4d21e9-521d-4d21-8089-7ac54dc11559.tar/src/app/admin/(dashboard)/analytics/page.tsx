"use client";

import { useCallback, useEffect, useState } from "react";
import { Eye, Globe2, MousePointerClick, TrendingUp, UserCheck, Info } from "lucide-react";
import {
  BarList,
  DeviceDonut,
  MonthlyTrendChart,
  TopPagesChart,
  VisitorsTrendChart,
} from "@/components/admin/Charts";
import { PageHeader, Panel, StatCard, LoadingBlock, ErrorBlock, EmptyState } from "@/components/admin/ui-bits";
import { adminFetch } from "@/lib/admin/client";
import { cn } from "@/lib/utils";

type Analytics = {
  range: string;
  cards: { views: number; visitors: number; uniques: number; avgPerVisit: number };
  daily: { date: string; views: number; visitors: number }[];
  monthly: { month: string; views: number; visitors: number }[];
  topPages: { path: string; views: number; visitors: number }[];
  devices: { device: string; count: number }[];
  sources: { source: string; count: number }[];
  countries: { country: string; count: number }[];
  countryAvailable: boolean;
  totalRows: number;
};

const RANGES = [
  { key: "24h", label: "24 hours" },
  { key: "7d", label: "7 days" },
  { key: "30d", label: "30 days" },
  { key: "90d", label: "90 days" },
];

export default function AdminAnalyticsPage() {
  const [range, setRange] = useState("7d");
  const [data, setData] = useState<Analytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    adminFetch<Analytics>(`/api/admin/analytics?range=${range}`)
      .then(setData)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [range]);

  useEffect(() => {
    const t = setTimeout(load, 0);
    return () => clearTimeout(t);
  }, [load]);

  const hasData = (data?.totalRows ?? 0) > 0;

  return (
    <>
      <PageHeader
        title="Website Analytics"
        subtitle="Privacy-first, cookieless measurement — no personal data is ever stored."
        actions={
          <div
            role="tablist"
            aria-label="Date range"
            className="flex rounded-full border border-white/10 bg-white/[0.03] p-1"
          >
            {RANGES.map((r) => (
              <button
                key={r.key}
                role="tab"
                aria-selected={range === r.key}
                onClick={() => setRange(r.key)}
                className={cn(
                  "rounded-full px-3.5 py-1.5 text-[12px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                  range === r.key ? "bg-electric-500 text-white" : "text-muted-foreground hover:text-white"
                )}
              >
                {r.label}
              </button>
            ))}
          </div>
        }
      />

      {loading ? (
        <LoadingBlock />
      ) : error ? (
        <ErrorBlock message={error} onRetry={load} />
      ) : data ? (
        <div className="space-y-6">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            <StatCard label="Total Visitors" value={data.cards.visitors} icon={TrendingUp} hint="Visit sessions in range" />
            <StatCard label="Unique Visitors" value={data.cards.uniques} icon={UserCheck} hint="Pseudonymous uniques" accent="white" />
            <StatCard label="Page Views" value={data.cards.views} icon={Eye} hint="Total views in range" accent="white" />
            <StatCard label="Views per Visit" value={data.cards.avgPerVisit} icon={MousePointerClick} hint="Engagement depth" />
          </div>

          {!hasData && (
            <div className="flex items-start gap-3 rounded-2xl border border-electric-500/25 bg-electric-500/[0.06] px-5 py-4">
              <Info className="mt-0.5 h-5 w-5 shrink-0 text-electric-400" aria-hidden />
              <p className="text-sm leading-relaxed text-foreground/80">
                No visitor data in this range yet. Analytics start collecting automatically from real traffic
                the moment your website is live — numbers shown here are never simulated.
              </p>
            </div>
          )}

          <Panel title="Daily trend" subtitle="Page views and visitors per day (IST).">
            {hasData ? <VisitorsTrendChart data={data.daily} /> : <EmptyState icon={TrendingUp} title="No daily data yet" message="The daily trend chart fills in as real visits arrive." />}
          </Panel>

          <Panel title="Monthly view" subtitle="All-time monthly totals within the recorded period.">
            {data.monthly.length > 0 ? (
              <MonthlyTrendChart data={data.monthly} />
            ) : (
              <EmptyState icon={TrendingUp} title="No monthly data yet" message="Monthly totals appear once visits have been recorded." />
            )}
          </Panel>

          <div className="grid gap-5 lg:grid-cols-2">
            <Panel title="Most visited pages" subtitle="Where visitors spend their time.">
              {data.topPages.length > 0 ? (
                <TopPagesChart data={data.topPages} />
              ) : (
                <EmptyState icon={Eye} title="No page data yet" message="Top pages appear as visitors browse the site." />
              )}
            </Panel>

            <Panel title="Device category" subtitle="Desktop vs Mobile vs Tablet.">
              {data.devices.length > 0 ? (
                <DeviceDonut data={data.devices} />
              ) : (
                <EmptyState icon={MousePointerClick} title="No device data yet" message="Device breakdown appears with real traffic." />
              )}
            </Panel>
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <Panel title="Traffic sources" subtitle="How visitors found the website.">
              <BarList
                items={data.sources.map((s) => ({ label: s.source, count: s.count }))}
                emptyLabel="Traffic sources appear as real visitors arrive."
              />
            </Panel>

            <Panel
              title="Visitor countries"
              subtitle="Country-level statistics, only where reliably available."
            >
              {data.countryAvailable ? (
                <BarList
                  items={data.countries.map((c) => ({ label: c.country, count: c.count }))}
                  emptyLabel="No country data in this range."
                />
              ) : (
                <div className="flex items-start gap-3 rounded-xl border border-dashed border-white/10 px-4 py-5">
                  <Globe2 className="mt-0.5 h-[18px] w-[18px] shrink-0 text-muted-foreground" aria-hidden />
                  <p className="text-[12.5px] leading-relaxed text-muted-foreground">
                    Country detection is not active in the current hosting environment. It switches on
                    automatically when the site runs behind an edge/CDN platform that provides geo headers
                    (e.g. Vercel or Cloudflare). No approximate location data is stored until then — and
                    even then, only the country code is kept, never precise locations.
                  </p>
                </div>
              )}
            </Panel>
          </div>
        </div>
      ) : null}
    </>
  );
}
