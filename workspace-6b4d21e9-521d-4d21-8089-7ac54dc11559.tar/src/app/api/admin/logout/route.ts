import { NextResponse } from "next/server";
import {
  getClientIp,
  logActivity,
  passesCsrfChecks,
  requireAdmin,
  revokeSession,
  SESSION_COOKIE,
} from "@/lib/admin/auth";

export async function POST(request: Request) {
  // Same-origin + custom-header check, consistent with every other mutating
  // admin endpoint (prevents cross-site logout attacks).
  if (!passesCsrfChecks(request)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const ctx = await requireAdmin(request);
  if (ctx) {
    await revokeSession(ctx.sessionId);
    await logActivity("logout", "admin signed out", getClientIp(request));
  }

  const response = NextResponse.json({ ok: true });
  response.cookies.set(SESSION_COOKIE, "", { httpOnly: true, path: "/", maxAge: 0 });
  return response;
}
