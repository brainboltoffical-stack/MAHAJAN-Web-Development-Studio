import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin/auth";
import { mailIntegrationName } from "@/lib/admin/mailer";

/** Infrastructure/integration status shown on the Settings page. */
export async function GET(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [lastEnquiry, lastAlert] = await Promise.all([
    db.notificationLog.findFirst({
      where: { type: "new_enquiry" },
      orderBy: { createdAt: "desc" },
      select: { status: true, createdAt: true },
    }),
    db.notificationLog.findFirst({
      where: { type: "security_alert" },
      orderBy: { createdAt: "desc" },
      select: { status: true, createdAt: true },
    }),
  ]);

  const proto =
    request.headers.get("x-forwarded-proto") ?? new URL(request.url).protocol.replace(":", "");

  return NextResponse.json({
    mail: { provider: mailIntegrationName(), lastEnquiry, lastAlert },
    https: { protocol: proto },
    backups: await backupInfo(),
  });
}

async function backupInfo(): Promise<{ last: string | null; count: number }> {
  try {
    const rows = await db.$queryRawUnsafe<{ file: string }[]>(
      "SELECT file FROM _backup_registry ORDER BY created_at DESC LIMIT 1"
    ).catch(() => [] as { file: string }[]);
    void rows;
    const fs = await import("node:fs");
    const path = await import("node:path");
    const dir = path.join(process.cwd(), "db", "backups");
    if (!fs.existsSync(dir)) return { last: null, count: 0 };
    const files = fs
      .readdirSync(dir)
      .filter((f) => f.endsWith(".db"))
      .sort()
      .reverse();
    return { last: files[0] ?? null, count: files.length };
  } catch {
    return { last: null, count: 0 };
  }
}
