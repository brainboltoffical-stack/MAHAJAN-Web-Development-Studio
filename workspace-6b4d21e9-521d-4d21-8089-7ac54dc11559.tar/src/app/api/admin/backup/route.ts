import { NextResponse } from "next/server";
import { mkdirSync } from "node:fs";
import { getClientIp, logActivity, passesCsrfChecks, requireAdmin } from "@/lib/admin/auth";

/**
 * Creates a consistent SQLite backup using VACUUM INTO.
 * Backups are written to db/backups/ on the server only.
 */
export async function POST(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!passesCsrfChecks(request)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  try {
    const now = new Date();
    const istName = new Date(now.getTime() + 330 * 60000)
      .toISOString()
      .replace(/[:.]/g, "-")
      .slice(0, 19);
    const fileName = `mahajan-backup-${istName}.db`;
    const dbUrl = process.env.DATABASE_URL ?? "";
    if (!dbUrl.startsWith("file:")) {
      return NextResponse.json({ error: "Backup requires a file-based SQLite database." }, { status: 400 });
    }
    const dbPath = dbUrl.replace("file:", "");

    const { dirname, join } = await import("node:path");
    const backupDir = join(dirname(dbPath), "backups");
    mkdirSync(backupDir, { recursive: true });

    const { db } = await import("@/lib/db");
    await db.$executeRawUnsafe(`VACUUM INTO '${join(backupDir, fileName)}'`);
    await logActivity("backup.created", fileName, getClientIp(request));

    return NextResponse.json({ ok: true, file: fileName });
  } catch (error) {
    console.error("[/api/admin/backup] failed:", error);
    return NextResponse.json({ error: "Backup failed. Check server logs." }, { status: 500 });
  }
}
