import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin/auth";
import { istDayStart } from "@/lib/admin/tracking";

const RANGES: Record<string, number> = { "24h": 1, "7d": 7, "30d": 30, "90d": 90 };

export async function GET(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const url = new URL(request.url);
  const rangeParam = url.searchParams.get("range") ?? "7d";
  const days = RANGES[rangeParam] ?? 7;

  const now = new Date();
  const rangeStart =
    days === 1 ? new Date(now.getTime() - 24 * 60 * 60 * 1000) : istDayStart(now).getTime() - (days - 1) * 86_400_000 > 0 ? new Date(istDayStart(now).getTime() - (days - 1) * 86_400_000) : new Date(now.getTime() - days * 86_400_000);

  const rows = await db.pageView.findMany({
    where: { createdAt: { gte: rangeStart } },
    select: {
      path: true,
      visitorDaily: true,
      visitorMonthly: true,
      device: true,
      source: true,
      referrerDomain: true,
      country: true,
      createdAt: true,
    },
  });

  // Cards
  const views = rows.length;
  const visitors = new Set(rows.map((r) => r.visitorDaily)).size;
  const uniques = new Set(rows.map((r) => r.visitorMonthly)).size;

  // Daily trend (IST day buckets)
  const dailyMap = new Map<string, { views: number; visitors: Set<string> }>();
  const dailyMonths = new Map<string, { views: number; visitors: Set<string> }>();
  for (const r of rows) {
    const shifted = new Date(r.createdAt.getTime() + 330 * 60000);
    const dayKey = shifted.toISOString().slice(5, 10);
    const monthKey = shifted.toISOString().slice(0, 7);
    const day = dailyMap.get(dayKey) ?? { views: 0, visitors: new Set<string>() };
    day.views += 1;
    day.visitors.add(r.visitorDaily);
    dailyMap.set(dayKey, day);
    const month = dailyMonths.get(monthKey) ?? { views: 0, visitors: new Set<string>() };
    month.views += 1;
    month.visitors.add(r.visitorMonthly);
    dailyMonths.set(monthKey, month);
  }

  const daily = Array.from(dailyMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, v]) => ({ date, views: v.views, visitors: v.visitors.size }));

  const monthly = Array.from(dailyMonths.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([month, v]) => ({ month, views: v.views, visitors: v.visitors.size }));

  // Top pages
  const pageMap = new Map<string, { views: number; visitors: Set<string> }>();
  for (const r of rows) {
    const p = pageMap.get(r.path) ?? { views: 0, visitors: new Set<string>() };
    p.views += 1;
    p.visitors.add(r.visitorDaily);
    pageMap.set(r.path, p);
  }
  const topPages = Array.from(pageMap.entries())
    .map(([path, v]) => ({ path, views: v.views, visitors: v.visitors.size }))
    .sort((a, b) => b.views - a.views)
    .slice(0, 10);

  // Devices
  const deviceMap = new Map<string, number>();
  for (const r of rows) deviceMap.set(r.device, (deviceMap.get(r.device) ?? 0) + 1);
  const devices = Array.from(deviceMap.entries()).map(([device, count]) => ({ device, count }));

  // Traffic sources
  const sourceMap = new Map<string, number>();
  for (const r of rows) sourceMap.set(r.source, (sourceMap.get(r.source) ?? 0) + 1);
  const sources = Array.from(sourceMap.entries())
    .map(([source, count]) => ({ source, count }))
    .sort((a, b) => b.count - a.count);

  // Countries — only reported when the platform provides geo data.
  const knownCountries = rows.filter((r) => r.country);
  const countryMap = new Map<string, number>();
  for (const r of knownCountries) countryMap.set(r.country as string, (countryMap.get(r.country as string) ?? 0) + 1);
  const countries = Array.from(countryMap.entries())
    .map(([country, count]) => ({ country, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);

  return NextResponse.json({
    range: rangeParam,
    cards: { views, visitors, uniques, avgPerVisit: visitors > 0 ? Math.round((views / visitors) * 10) / 10 : 0 },
    daily,
    monthly,
    topPages,
    devices,
    sources,
    countries,
    countryAvailable: rows.length > 0 && knownCountries.length > 0,
    totalRows: rows.length,
  });
}
