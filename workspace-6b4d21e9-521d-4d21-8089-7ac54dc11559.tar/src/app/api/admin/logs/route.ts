import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin/auth";

/** Recent admin activity + login attempts. Passwords/tokens are never logged. */
export async function GET(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [activity, attempts] = await Promise.all([
    db.adminActivityLog.findMany({ orderBy: { createdAt: "desc" }, take: 40 }),
    db.loginAttempt.findMany({ orderBy: { createdAt: "desc" }, take: 40 }),
  ]);

  return NextResponse.json({ activity, attempts });
}
