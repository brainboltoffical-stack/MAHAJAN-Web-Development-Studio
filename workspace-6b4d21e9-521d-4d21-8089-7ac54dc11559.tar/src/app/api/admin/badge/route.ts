import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/admin/auth";

/** Lightweight unread counter for the sidebar badge. */
export async function GET(request: Request) {
  const ctx = await requireAdmin(request);
  if (!ctx) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const unread = await db.projectInquiry.count({ where: { isRead: false } });
  return NextResponse.json({ unread });
}
