import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { rateLimit } from "@/lib/admin/rate-limit";
import {
  classifyReferrer,
  detectCountry,
  detectDevice,
  isBot,
  normalisePath,
  visitorHashes,
} from "@/lib/admin/tracking";
import { getClientIp, ipHash } from "@/lib/admin/auth";

/**
 * Privacy-first, cookieless page-view beacon for the public website.
 * - stores NO personal data: pseudonymous daily/monthly visitor hashes only
 * - respects the browser Do-Not-Track signal (also enforced client-side)
 * - ignores bots, admin/api paths and abusive request rates
 */
export async function POST(request: Request) {
  try {
    if ((request.headers.get("dnt") ?? "") === "1") {
      return new NextResponse(null, { status: 204 });
    }

    const ip = getClientIp(request);
    const limited = rateLimit(`track:${ipHash(ip) ?? "unknown"}`, 30, 60_000);
    if (!limited.allowed) return new NextResponse(null, { status: 204 });

    const body = (await request.json().catch(() => ({}))) as { p?: string; r?: string };
    const userAgent = request.headers.get("user-agent");

    if (isBot(userAgent)) return new NextResponse(null, { status: 204 });

    const path = normalisePath(body.p);
    if (!path) return new NextResponse(null, { status: 204 });

    const { source, domain } = classifyReferrer(body.r ?? null);
    const { visitorDaily, visitorMonthly } = visitorHashes(ip, userAgent);

    await db.pageView.create({
      data: {
        path,
        visitorDaily,
        visitorMonthly,
        device: detectDevice(userAgent),
        source,
        referrerDomain: domain,
        country: detectCountry(request.headers),
      },
    });

    return new NextResponse(null, { status: 204 });
  } catch {
    // Analytics must never break the user experience.
    return new NextResponse(null, { status: 204 });
  }
}
