import type { Metadata, Viewport } from "next";
import { Inter, Space_Grotesk, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "MAHAJAN Web Development Studio — Websites That Build Your Business",
  description:
    "MAHAJAN Web Development Studio helps small businesses in the UK, USA, Canada and Australia build a strong digital presence with modern, responsive and professional websites. Business websites, e-commerce stores, Shopify design, redesigns and landing pages.",
  keywords: [
    "web development studio",
    "business website design",
    "e-commerce website development",
    "Shopify store design",
    "website redesign",
    "responsive web design",
    "landing page development",
    "MAHAJAN Web Development Studio",
    "Khushal Mahajan",
  ],
  authors: [{ name: "Khushal Mahajan" }],
  creator: "MAHAJAN Web Development Studio",
  metadataBase: new URL("https://mahajan.studio"),
  openGraph: {
    title: "MAHAJAN Web Development Studio — Websites That Build Your Business",
    description:
      "Modern, responsive and professional websites for growing small businesses. Business websites, e-commerce, Shopify stores and landing pages.",
    siteName: "MAHAJAN Web Development Studio",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "MAHAJAN Web Development Studio",
    description:
      "Modern, responsive and professional websites for growing small businesses.",
  },
  robots: {
    index: true,
    follow: true,
  },
};

export const viewport: Viewport = {
  themeColor: "#05060b",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${spaceGrotesk.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
