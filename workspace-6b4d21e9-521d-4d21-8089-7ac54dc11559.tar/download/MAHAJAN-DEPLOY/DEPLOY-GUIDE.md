# MAHAJAN Website — Apne Permanent URL Par Deploy Karne Ki Guide

**Target:** Vercel (hosting) + Neon (database) — dono ke **free plans** hain, credit card nahi chahiye.
**Time:** Pehli baar ~30 minute. **Result:** `https://aapki-website.vercel.app` par valid SSL ke saath live website — **koi certificate warning nahi**, hamesha chalega.

> Sach baat: Preview sandbox ka SSL platform ke control me hai. Yeh guide aapko **apna permanent URL** dila degi jiska SSL aapke control me hoga. Deploy aapke accounts (GitHub/Vercel/Neon) se hoga — is package me sab ready-made steps aur files hain.

---

## Aapko kya chahiye (sab free)

| Cheez | Kahan | Kyun |
|---|---|---|
| GitHub account | github.com | Code upload karne ke liye |
| Vercel account | vercel.com | Website host karne ke liye (GitHub se login) |
| Neon account | neon.tech | Database ke liye (GitHub se login) |
| Project folder | Yeh pura project | Aapke paas already hai |

---

## Step 1 — Database banao (Neon, ~3 min)

1. **neon.tech** kholo → **Sign Up with GitHub**
2. **New Project** → Name: `mahajan-db` → Region: **Singapore** (India ke liye fastest) → **Create**
3. Dashboard me **Connection string** dikhega (aisa hoga: `postgresql://user:pass@ep-xyz...neon.tech/neondb?sslmode=require`)
4. **Copy kar lo** — yehi `DATABASE_URL` hai. Kisi se share mat karna.

---

## Step 2 — Database ko Postgres mode me switch karo (~2 min)

Project folder me (jahan `package.json` hai) terminal kholo:

```bash
# Original SQLite schema ka backup
cp prisma/schema.prisma prisma/schema.sqlite.prisma

# Is package wala Postgres schema copy karo
cp <is-package-ka-path>/schema.postgres.prisma prisma/schema.prisma
```

Ab project root me `.env` file banao (ya existing me add karo):

```bash
DATABASE_URL="yahan-Neon-ka-connection-string-paste-karo"
AUTH_SECRET="yahan-random-64-char-hex"   # generate: openssl rand -hex 32
```

> Note: sandbox me banaya hua `ADMIN_TRUSTED_ORIGINS` (preview URL wala) yahan ki zaroorat NahI hai — Vercel par Host header sahi aata hai. Filhal `.env` me rahne do, koi nuksan nahi.

---

## Step 3 — Tables banao + Admin account set karo (~3 min)

```bash
bun install                # ya: npm install
bunx prisma db push        # Neon database me saari tables ban jayengi

# Admin account banao (password 12+ characters, strong):
ADMIN_USERNAME="Jaguu" \
ADMIN_EMAIL="brainboltoffical@gmail.com" \
ADMIN_PASSWORD="ApnaStrongPasswordYahanLikho12+" \
bun scripts/seed-admin.ts
```

- Password sirf environment se padha jata hai — kisi file me save NAHI hota. Database me sirf scrypt hash jata hai.
- Aapki purani preview wali website ka data (enquiries/analytics) Neon me nahi jayega — fresh start hoga. Purana data chahiye to pehle backup: `bun run db:backup` (sandbox me) — phir batao, main migrate script bana dunga.

---

## Step 4 — Code GitHub par daalo (~5 min)

1. **github.com/new** → Repo name: `mahajan-website` → **Private** select karo → Create
2. Project folder me:

```bash
git init
git add .
git commit -m "MAHAJAN Web Development Studio — production ready"
git remote add origin https://github.com/APNA-USERNAME/mahajan-website.git
git branch -M main
git push -u origin main
```

> Check: `.gitignore` me `.env` hona chahiye (project me already hai). `db/custom.db` bhi push mat hona chahiye — agar `git status` me dikhe to `git rm --cached db/custom.db` chala kar commit karo.

---

## Step 5 — Vercel par deploy (~5 min)

1. **vercel.com** → **Continue with GitHub**
2. **Add New → Project** → `mahajan-website` repo → **Import**
3. **Environment Variables** section me yeh 3 add karo:

| Name | Value |
|---|---|
| `DATABASE_URL` | Neon ka connection string |
| `AUTH_SECRET` | wahi 64-char random hex |
| `ADMIN_TRUSTED_ORIGINS` | `https://mahajan-website.vercel.app` (deploy ke baad jo URL mile, wahi — baad me add kar sakte ho) |

4. **Deploy** dabao → 2-3 minute
5. **Ho gaya!** URL milega: `https://mahajan-website.vercel.app` — **SSL automatic valid**, koi warning kabhi nahi.

> Build command kuch mat badalna — project ka `package.json` already Vercel-compatible hai.

---

## Step 6 — Deploy ke baad check-list

- [ ] Website kholo — home page, Services, Work, Contact sections dikh rahe hain
- [ ] Contact form se ek test enquiry bhejo → admin panel me dikhni chahiye
- [ ] Footer me "MS" par click → `/admin/login` khule
- [ ] Login karo (username: **Jaguu** + jo password Step 3 me set kiya)
- [ ] **Settings → Change Password** — pehle kaam: apna naya password set karo
- [ ] `ADMIN_TRUSTED_ORIGINS` me Vercel wala final URL add karo (agar login/logout me dikkat ho)

---

## Optional — Apna Domain (jaise mahajanwebstudio.com)

1. Domain kharido (Namecheap/GoDaddy/Cloudflare se, ~₹800-1000/saal)
2. Vercel → Project → **Settings → Domains** → apna domain add karo
3. Domain provider ke DNS me Vercel jo records bole (A/CNAME) wo paste karo
4. **SSL certificate Vercel khud bana dega** — free, auto-renew

---

## Agar Vercel pasand na aaye: Railway (alternative, ~0 code change)

Railway.app GitHub repo import karo → Variables me `DATABASE_URL=file:/data/custom.db` + ek Volume `/data` attach karo. SQLite schema waisa ka waisa chalega. Free trial ke baad $5/month.

---

## Security notes (honest)

- Password scrypt hash me store hota hai, plaintext kabhi nahi.
- Session HTTP-only cookie + server-side revocation, login par brute-force lock (5 galat attempts → 15 min), CSRF protection, activity log — sab production me bhi active.
- `AUTH_SECRET` production me zaroor set karo (upar Step 2) — warna deterministic fallback use hota hai jo dev ke liye hai.
- Koi system "unhackable" nahi hota — best practices follow ki hain, lekin apna password strong rakho aur use share mat karo.
