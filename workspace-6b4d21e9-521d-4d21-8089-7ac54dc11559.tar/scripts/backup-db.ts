/**
 * Creates a consistent SQLite backup of the MAHAJAN database.
 *
 *   bun run db:backup
 *
 * Uses SQLite's VACUUM INTO (consistent snapshot, safe while the app runs).
 * Backups are written to db/backups/ on the server — copy them off the machine
 * for full disaster-recovery safety.
 */
import { PrismaClient } from "@prisma/client";
import { mkdirSync } from "node:fs";
import { dirname, join } from "node:path";

const prisma = new PrismaClient();

async function main() {
  const dbUrl = process.env.DATABASE_URL ?? "";
  if (!dbUrl.startsWith("file:")) {
    console.error("DATABASE_URL must be a file-based SQLite URL.");
    process.exit(1);
  }
  const dbPath = dbUrl.replace("file:", "");
  const backupDir = join(dirname(dbPath), "backups");
  mkdirSync(backupDir, { recursive: true });

  const stamp = new Date(Date.now() + 330 * 60000)
    .toISOString()
    .replace(/[:.]/g, "-")
    .slice(0, 19);
  const fileName = `mahajan-backup-${stamp}.db`;

  await prisma.$executeRawUnsafe(`VACUUM INTO '${join(backupDir, fileName)}'`);
  console.log(`Backup created: ${fileName} (in ${backupDir})`);
}

main()
  .catch((e) => {
    console.error("Backup failed:", e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
