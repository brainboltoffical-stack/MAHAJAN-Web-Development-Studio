#!/usr/bin/env bash
# MAHAJAN admin panel — end-to-end browser UI test.
# Requires the dev server on localhost:3000. Never prints the password.
set -u
cd /home/z/my-project
# Password is supplied via environment only — never stored in this file.
PW="${ADMIN_PASSWORD:?Set ADMIN_PASSWORD in the environment to run this test}"
PW_SECRET="${PW:0:5}" # short fragment used only for the leak scan
BASE_URL="${BASE_URL:-http://localhost:3000}"
AB="agent-browser"
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  PASS  $1"; }
bad()  { FAIL=$((FAIL+1)); echo "  FAIL  $1"; }

mkdir -p /tmp/render

echo "== 0. Public site source must not contain the admin username =="
HOMEPAGE=$(curl -s "$BASE_URL/")
LOGINPAGE=$(curl -s "$BASE_URL/admin/login")
echo "$HOMEPAGE" | rg -q "Jaguu" && bad "homepage leaks username" || ok "homepage clean"
echo "$LOGINPAGE" | rg -q "Jaguu" && bad "login page leaks username" || ok "login page clean"
echo "$HOMEPAGE" | rg -qi "$PW_SECRET|password" && bad "homepage leaks secret-like strings" || ok "homepage has no secret strings"

echo "== 1. Login page renders =="
$AB open "$BASE_URL/admin/login" >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1
URL=$($AB get url 2>/dev/null)
echo "$URL" | rg -q "/admin/login" && ok "login page reachable" || bad "login page url: $URL"
$AB screenshot /tmp/render/ui-01-login.png >/dev/null 2>&1

echo "== 2. Wrong password shows a clear error (not hidden) =="
$AB find label "Username or Email" fill "Jaguu" >/dev/null 2>&1
$AB find label "Password" fill "totally-wrong-pass" >/dev/null 2>&1
$AB find text "Sign In Securely" click >/dev/null 2>&1
$AB wait --text "Invalid credentials" --timeout 15000 >/dev/null 2>&1
ERR=$($AB find text "Invalid credentials" text 2>/dev/null | head -1)
[ -n "$ERR" ] && ok "error message shown: $ERR" || bad "no visible error after wrong password"
URL=$($AB get url 2>/dev/null)
echo "$URL" | rg -q "/admin/login" && ok "stays on login page" || bad "unexpected url: $URL"
$AB screenshot /tmp/render/ui-02-wrong-credentials.png >/dev/null 2>&1

echo "== 3. Correct credentials open the dashboard =="
$AB find label "Username or Email" fill "Jaguu" >/dev/null 2>&1
$AB find label "Password" fill "$PW" >/dev/null 2>&1
$AB find text "Sign In Securely" click >/dev/null 2>&1
$AB wait --url "/admin" --timeout 20000 >/dev/null 2>&1
sleep 2
URL=$($AB get url 2>/dev/null)
echo "$URL" | rg -q "/admin/login" && bad "still on login after correct login" || ok "redirected away from login: $URL"
$AB wait --load networkidle >/dev/null 2>&1
$AB screenshot /tmp/render/ui-03-dashboard.png >/dev/null 2>&1
SNAP=$($AB snapshot -c 2>/dev/null)
echo "$SNAP" | rg -qi "overview" && ok "dashboard Overview renders" || bad "dashboard content missing"
echo "$SNAP" | rg -qi "messages" && ok "sidebar nav (Messages) present" || bad "no Messages nav"

echo "== 4. Authenticated dashboard source has no username =="
LEAK=$($AB eval "document.documentElement.outerHTML.includes('Jaguu')" 2>/dev/null)
[ "$LEAK" = "false" ] && ok "dashboard HTML clean (no username)" || bad "dashboard HTML contains username: $LEAK"

echo "== 5. Dashboard sections load =="
$AB find text "Messages" click >/dev/null 2>&1; sleep 2
$AB wait --load networkidle >/dev/null 2>&1
$AB screenshot /tmp/render/ui-04-messages.png >/dev/null 2>&1
M=$($AB snapshot -c 2>/dev/null); echo "$M" | rg -qi "inbox|messages|enquir" && ok "Messages page renders" || bad "Messages page broken"
$AB find text "Analytics" click >/dev/null 2>&1; sleep 2
$AB wait --load networkidle >/dev/null 2>&1
$AB screenshot /tmp/render/ui-05-analytics.png >/dev/null 2>&1
A=$($AB snapshot -c 2>/dev/null); echo "$A" | rg -qi "analytics|visitors|views" && ok "Analytics page renders" || bad "Analytics page broken"
$AB find text "Settings" click >/dev/null 2>&1; sleep 2
$AB wait --load networkidle >/dev/null 2>&1
$AB screenshot /tmp/render/ui-06-settings.png >/dev/null 2>&1
S=$($AB snapshot -c 2>/dev/null); echo "$S" | rg -qi "settings|password|security" && ok "Settings page renders" || bad "Settings page broken"

echo "== 6. Logout returns to login =="
$AB find role button click --name "Logout" >/dev/null 2>&1 || $AB eval "const b=Array.from(document.querySelectorAll('button')).find(x=>/log\s?out/i.test(x.textContent)&&x.offsetParent!==null); b&&b.click(); b?'js-clicked':'none'" >/dev/null 2>&1
$AB wait --url "/admin/login" --timeout 20000 >/dev/null 2>&1
sleep 1
URL=$($AB get url 2>/dev/null)
echo "$URL" | rg -q "/admin/login" && ok "logout lands on login page" || bad "logout url: $URL"

echo "== 7. Direct /admin access after logout redirects to login =="
$AB open "$BASE_URL/admin" >/dev/null 2>&1
$AB wait --load networkidle >/dev/null 2>&1; sleep 1
URL=$($AB get url 2>/dev/null)
echo "$URL" | rg -q "/admin/login" && ok "unauthenticated /admin redirected to login" || bad "unauthenticated /admin shows: $URL"

echo "== 8. Browser console/page errors =="
ERRS=$($AB errors 2>/dev/null | tail -n +2 | rg -v "^\s*$" | head -5)
[ -z "$ERRS" ] && ok "no page errors" || bad "page errors: $ERRS"

$AB close >/dev/null 2>&1
echo ""
echo "UI RESULT: $PASS passed, $FAIL failed"
exit $([ $FAIL -eq 0 ] && echo 0 || echo 1)
