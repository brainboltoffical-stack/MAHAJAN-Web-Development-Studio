#!/bin/bash
# Generate portfolio demo images for MAHAJAN website
mkdir -p /home/z/my-project/public/work

z-ai image -p "High-end fashion e-commerce website homepage design, flat UI screen mockup, elegant editorial layout with large hero photo of stylish female model in beige trench coat, minimalist white and cream color palette, refined serif typography headline, clean product grid of clothing items below, luxury web design aesthetic, professional UI design, crisp and detailed, high quality" -o /home/z/my-project/public/work/fashion-store.png -s 1344x768 &

z-ai image -p "Modern restaurant website homepage design, flat UI screen mockup, dark moody elegant layout, large hero photo of gourmet plated dish on wooden table, warm amber and charcoal color palette, contemporary sans-serif typography, menu section with food photography cards below, upscale dining web design, professional UI design, crisp and detailed, high quality" -o /home/z/my-project/public/work/restaurant.png -s 1344x768 &

z-ai image -p "Beauty salon website homepage design, flat UI screen mockup, soft luxurious layout, hero photo of serene spa treatment scene with rose gold and blush pink tones, elegant thin typography, booking appointment section, service cards for hair and skincare below with soft photography, feminine premium web design, professional UI design, crisp and detailed, high quality" -o /home/z/my-project/public/work/beauty-salon.png -s 1344x768 &

wait
echo "All images generated"
ls -la /home/z/my-project/public/work/
