/**
 * MAHAJAN admin authentication — end-to-end API test suite.
 * Verifies the complete server-side auth lifecycle against a running dev server.
 * Never prints credentials; only HTTP outcomes.
 */
const BASE = process.env.BASE_URL || "http://localhost:3000";
const USERNAME = process.env.ADMIN_USERNAME || "Jaguu";
const PASSWORD = process.env.ADMIN_PASSWORD || "";

let pass = 0;
let fail = 0;

function check(name, cond, extra = "") {
  if (cond) {
    pass++;
    console.log(`  PASS  ${name}`);
  } else {
    fail++;
    console.log(`  FAIL  ${name} ${extra}`);
  }
}

async function login(identifier, password) {
  const res = await fetch(`${BASE}/api/admin/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identifier, password }),
  });
  return res;
}

async function main() {
  console.log("== 1. Login rejects wrong password with a clear error ==");
  const bad = await login(USERNAME, "definitely-wrong-password");
  const badBody = await bad.json().catch(() => ({}));
  check("status is 401", bad.status === 401, `got ${bad.status}`);
  check("error message present", typeof badBody.error === "string" && badBody.error.length > 5, JSON.stringify(badBody));
  check("no session cookie set on failure", !(bad.headers.get("set-cookie") || "").includes("mahajan_admin="));

  console.log("== 2. Login rejects empty payload ==");
  const empty = await fetch(`${BASE}/api/admin/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  });
  check("status is 400", empty.status === 400, `got ${empty.status}`);

  console.log("== 3. Login succeeds with configured credentials ==");
  const ok = await login(USERNAME, PASSWORD);
  const okBody = await ok.json().catch(() => ({}));
  check("status is 200", ok.status === 200, `got ${ok.status}: ${JSON.stringify(okBody)}`);
  const setCookie = ok.headers.get("set-cookie") || "";
  check("session cookie issued", setCookie.includes("mahajan_admin="));
  check("cookie is HttpOnly", /httponly/i.test(setCookie));
  check("cookie is SameSite=Lax", /samesite=lax/i.test(setCookie));
  const cookie = setCookie.split(";")[0];

  console.log("== 4. Login response leaks no credentials/tokens ==");
  const okRaw = JSON.stringify(okBody);
  check("body has no password/token fields", !/password|token|secret|hash/i.test(okRaw), okRaw.slice(0, 200));

  console.log("== 5. Admin API is protected ==");
  const anonApi = await fetch(`${BASE}/api/admin/overview`);
  check("overview without cookie -> 401", anonApi.status === 401, `got ${anonApi.status}`);
  const anonApi2 = await fetch(`${BASE}/api/admin/messages`);
  check("messages without cookie -> 401", anonApi2.status === 401, `got ${anonApi2.status}`);
  const anonApi3 = await fetch(`${BASE}/api/admin/analytics`);
  check("analytics without cookie -> 401", anonApi3.status === 401, `got ${anonApi3.status}`);

  console.log("== 6. Admin page redirects anonymous visitors ==");
  const anonPage = await fetch(`${BASE}/admin`, { redirect: "manual" });
  check("GET /admin redirects (3xx)", anonPage.status >= 300 && anonPage.status < 400, `got ${anonPage.status}`);
  const loc = anonPage.headers.get("location") || "";
  check("redirects to /admin/login", loc.includes("/admin/login"), `location=${loc}`);

  console.log("== 7. Authenticated admin API works ==");
  const authed = await fetch(`${BASE}/api/admin/overview`, { headers: { cookie: cookie } });
  check("overview with session -> 200", authed.status === 200, `got ${authed.status}`);
  const overview = await authed.json().catch(() => ({}));
  check("overview payload has stats", typeof overview === "object" && overview !== null && Object.keys(overview).length > 0);

  console.log("== 8. CSRF: mutating endpoints require the custom header ==");
  const noCsrf = await fetch(`${BASE}/api/admin/logout`, {
    method: "POST",
    headers: { cookie: cookie, "Content-Type": "application/json" },
  });
  check("logout without x-mahajan-admin -> 403", noCsrf.status === 403, `got ${noCsrf.status}`);

  console.log("== 9. Logout revokes the session server-side ==");
  const out = await fetch(`${BASE}/api/admin/logout`, {
    method: "POST",
    headers: { cookie: cookie, "Content-Type": "application/json", "x-mahajan-admin": "1" },
  });
  check("logout with CSRF header -> 200", out.status === 200, `got ${out.status}`);
  const after = await fetch(`${BASE}/api/admin/overview`, { headers: { cookie: cookie } });
  check("old cookie rejected after logout -> 401", after.status === 401, `got ${after.status}`);

  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail > 0 ? 1 : 0);
}

main().catch((e) => {
  console.error("SUITE ERROR:", e.message);
  process.exit(1);
});
